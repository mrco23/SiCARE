import { NavLink, Outlet } from "react-router-dom";
import NotificationBell from "../components/shared/NotificationBell";
import NavbarProfileDropdown from "../components/shared/NavbarProfileDropdown";
import {
  Activity,
  CalendarDays,
  History,
  Home,
  Users,
  type LucideIcon,
} from "lucide-react";

/* ========================= MENU ========================= */
const NAV_ITEMS: {
  to: string;
  label: string;
  short: string;
  icon: LucideIcon;
}[] = [
  { to: "/klien", label: "Beranda", short: "Beranda", icon: Home },
  {
    to: "/klien/pesanan",
    label: "Pesanan Konseling",
    short: "Pesanan",
    icon: CalendarDays,
  },
  { to: "/klien/konselor", label: "Konselor", short: "Konselor", icon: Users },
  {
    to: "/klien/aktivitas",
    label: "Aktivitas Saya",
    short: "Aktivitas",
    icon: Activity,
  },
  { to: "/klien/riwayat", label: "Riwayat", short: "Riwayat", icon: History },
];

export default function KlienLayout() {
  return (
    <div className="min-h-screen bg-gray-50 pb-24 font-sans text-gray-900 antialiased lg:pb-0">
      {/* ================= NAVBAR ================= */}
      <header className="sticky top-0 z-50 px-3 pt-2 sm:px-5">
        <div className="relative mx-auto flex h-14 w-full max-w-7xl items-center justify-between rounded-full bg-white/90 px-4 shadow-[0_18px_40px_rgba(0,0,0,0.12)] backdrop-blur sm:h-16 sm:px-5 lg:px-6">
          <NavLink to="/" className="flex min-w-0 items-center gap-2 sm:gap-3">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full border-[1.5px] border-brand-gold bg-white sm:h-10 sm:w-10">
              <img
                src="/icon-512x512.png"
                alt="Logo Unika De La Salle Manado"
                className="h-6 w-6 rounded-full object-contain sm:h-7 sm:w-7"
              />
            </div>
            <div className="min-w-0">
              <div className="text-lg font-semibold leading-none sm:text-xl">
                <span className="text-brand-mark">Si</span>
                <span className="text-blue-900">CARE</span>
              </div>
              <p className="mt-1 truncate text-[10px] font-semibold text-[#2b2b2b] sm:text-[11px]">
                Universitas Katolik De La Salle Manado
              </p>
            </div>
          </NavLink>

          <nav className="hidden items-center gap-6 font-display text-[13px] text-gray-900 lg:flex xl:gap-10">
            {NAV_ITEMS.map((item) => (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/klien"}
                className={({ isActive }) =>
                  isActive
                    ? "border-b-2 border-primary pb-1 font-semibold text-primary"
                    : "hover:text-primary"
                }
              >
                {item.label}
              </NavLink>
            ))}
          </nav>

          <div className="flex items-center gap-2.5 sm:gap-3 shrink-0">
            <NotificationBell
              role="client"
              wrapperClassName="relative shrink-0"
              buttonClassName="flex h-10 w-10 items-center justify-center rounded-full text-slate-700 transition-colors hover:bg-gray-100 hover:text-primary focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/40"
            />
            <NavbarProfileDropdown role="client" wrapperClassName="shrink-0" />
          </div>
        </div>
      </header>

      {/* ================= NAVIGASI BAWAH (MOBILE) ================= */}
      <nav
        aria-label="Navigasi utama"
        className="fixed inset-x-0 bottom-0 z-50 border-t border-gray-200 bg-white/95 px-1 pb-[env(safe-area-inset-bottom)] backdrop-blur lg:hidden"
      >
        <div className="mx-auto grid max-w-md grid-cols-5">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                end={item.to === "/klien"}
                className={({ isActive }) =>
                  `flex flex-col items-center gap-0.5 py-2 text-[11px] ${
                    isActive
                      ? "font-semibold text-primary"
                      : "font-medium text-gray-500"
                  }`
                }
              >
                <Icon className="h-5 w-5" strokeWidth={1.8} />
                {item.short}
              </NavLink>
            );
          })}
        </div>
      </nav>

      {/* ================= KONTEN HALAMAN ================= */}
      <main className="mx-auto w-[92%] max-w-7xl pb-12 pt-6 sm:w-[88%] sm:pt-8 lg:w-[86%]">
        <Outlet />
      </main>
    </div>
  );
}
