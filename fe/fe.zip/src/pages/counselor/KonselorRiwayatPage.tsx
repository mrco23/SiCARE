import { PageContainer, PageHeader } from "../../components/shared";
import { useCallback, useEffect, useMemo, useState } from "react";
import type { FormEvent } from "react";
import { useNavigate } from "react-router-dom";
import {
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  Download,
  Eye,
  EyeOff,
  FileSignature,
  Lock,
  Search,
  ShieldAlert,
  X,
} from "lucide-react";
import {
  isInPeriod,
  loadPeriods,
  sortPeriods,
  toISO,
} from "../../lib/academicPeriods";
import { clients as mockClients, type Client } from "../../data/mock/counselorHistory";
import type { CounselingFormat as Format } from "../../types/counseling";
import {
  formatBookingClientTitle,
  formatBookingRepresentative,
  getCounselorInitials as initials,
} from "../../features/counselor/shared/presentation";
import { useCounselorHistoryAccess } from "../../features/history/hooks/useCounselorHistoryAccess";
import {
  counselorHistorySessionKey as sessionKey,
  formatCounselorHistoryDate as fmtDate,
  getCounselorHistoryDateRange as getDateRange,
  getCounselorHistoryDateRangeLabel as dateRangeLabel,
  matchesCounselorHistoryFilter as matches,
  type CounselorHistoryPeriod as PeriodKey,
} from "../../features/counselor/history/historySelectors";
import { sicareApi } from "../../lib/sicareApi";
import type { BookingRecordBaseDto, SessionListItemDto } from "../../types/api";

const PERIOD_OPTIONS: [PeriodKey, string][] = [
  ["hari", "Hari"],
  ["minggu", "Minggu"],
  ["bulan", "Bulan"],
  ["semester", "Semester"],
];

const CONSENT_PDF_URL = "/informed-consent.pdf";

export default function KonselorRiwayatPage() {
  const navigate = useNavigate();
  const today = useMemo(() => toISO(new Date()), []);
  const periods = useMemo(() => sortPeriods(loadPeriods()), []);
  const defaultSemester =
    periods.find((p) => isInPeriod(today, p)) ??
    periods[periods.length - 1] ??
    null;

  const [period, setPeriod] = useState<PeriodKey>("bulan");
  const [anchor, setAnchor] = useState(
    () =>
      new Date(
        new Date().getFullYear(),
        new Date().getMonth(),
        new Date().getDate(),
        12,
      ),
  );
  const [semesterId, setSemesterId] = useState<string | null>(
    defaultSemester?.id ?? null,
  );
  const [format, setFormat] = useState<Format>("Individu");
  const [query, setQuery] = useState("");
  const [timeSort, setTimeSort] = useState<"terbaru" | "terlama">("terbaru");

  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [noteId, setNoteId] = useState<string | number | null>(null);
  const [consentSessionId, setConsentSessionId] = useState<string | number | null>(null);

  const [pwInput, setPwInput] = useState("");
  const [pwVisible, setPwVisible] = useState(false);
  const [pwError, setPwError] = useState("");
  const [verifying, setVerifying] = useState(false);

  const [toastMsg, setToastMsg] = useState("");

  const handleAccessExpired = useCallback(() => {
    setSelectedId(null);
    setNoteId(null);
    setConsentSessionId(null);
    setToastMsg("Akses riwayat terkunci kembali.");
  }, []);

  const handleCooldownExpired = useCallback(() => setPwError(""), []);

  const {
    attemptState,
    hasAccess,
    timerText,
    isPasswordLocked: pwLocked,
    maxAttempts: MAX_ATTEMPTS,
    unlock: unlockHistory,
    lock: lockHistory,
  } = useCounselorHistoryAccess(handleAccessExpired, handleCooldownExpired);

  // Live session and booking data from backend API
  const [apiClients, setApiClients] = useState<Client[]>([]);

  useEffect(() => {
    let active = true;
    Promise.all([
      sicareApi.sessions(100).catch(() => [] as SessionListItemDto[]),
      sicareApi.bookings(100).catch(() => [] as BookingRecordBaseDto[]),
    ]).then(([sessionsRes, bookingsRes]) => {
      if (!active) return;
      if (!sessionsRes || sessionsRes.length === 0) return;

      const bookingMap = new Map<string, BookingRecordBaseDto>();
      for (const b of bookingsRes) {
        bookingMap.set(b.id, b);
      }

      // Group completed sessions by client
      const clientMap = new Map<string, Client>();
      for (const s of sessionsRes) {
        if (s.status !== "completed" && s.status !== "cancelled") continue;
        const b = bookingMap.get(s.booking_id);
        const clientId = b?.client_id || b?.id || s.id;
        const repName = formatBookingRepresentative(b);
        const clientName = repName || formatBookingClientTitle(b);
        const clientRole = "Mahasiswa";

        if (!clientMap.has(clientId)) {
          clientMap.set(clientId, {
            id: clientId,
            name: clientName,
            email: "klien@unikadelasalle.ac.id",
            role: clientRole,
            password: "",
            sessions: [],
          });
        }

        const client = clientMap.get(clientId)!;
        const startDate = s.starts_at.split("T")[0] || today;
        const startTime = s.starts_at.includes("T")
          ? s.starts_at.split("T")[1].slice(0, 5).replace(":", ".")
          : "10.00";

        client.sessions.push({
          id: Number(s.id.replace(/\D/g, "").slice(0, 8)) || Date.now(),
          topic: b?.group_name
            ? `Konseling Kelompok: ${b.group_name}`
            : "Konseling Pengembangan Diri & Akademik",
          format: b?.service_type === "group" ? "Kelompok" : "Individu",
          date: startDate,
          time: startTime,
          summary: `Sesi konseling telah selesai dilaksanakan di ${s.room || "Ruang Konseling LMI"}.`,
          note: "Catatan sesi konselor tersimpan secara aman dalam arsip rekam medis SiCARE.",
        });
      }

      if (clientMap.size > 0) {
        setApiClients(Array.from(clientMap.values()));
      }
    });

    return () => {
      active = false;
    };
  }, [today]);

  const allClients = useMemo(() => {
    if (apiClients.length === 0) return mockClients;
    const existingIds = new Set(apiClients.map((c) => c.id));
    const supplemental = mockClients.filter((c) => !existingIds.has(c.id));
    return [...apiClients, ...supplemental];
  }, [apiClients]);

  const allSessions = useMemo(
    () => allClients.flatMap((c) => c.sessions),
    [allClients],
  );

  // Sembunyikan toast otomatis.
  useEffect(() => {
    if (!toastMsg) return;
    const t = setTimeout(() => setToastMsg(""), 2800);
    return () => clearTimeout(t);
  }, [toastMsg]);

  const semester = periods.find((p) => p.id === semesterId) ?? null;
  const range = useMemo(
    () => getDateRange(period, anchor, semester),
    [period, anchor, semester],
  );
  const label = dateRangeLabel(period, range, semester);

  function stepPeriod(direction: -1 | 1) {
    if (period === "semester") {
      const index = periods.findIndex((p) => p.id === semesterId);
      const next = periods[index + direction];
      if (next) setSemesterId(next.id);
      return;
    }
    const next = new Date(anchor);
    if (period === "hari") next.setDate(next.getDate() + direction);
    else if (period === "minggu") next.setDate(next.getDate() + 7 * direction);
    else {
      next.setDate(15);
      next.setMonth(next.getMonth() + direction);
    }
    setAnchor(next);
  }

  const semesterIndex = periods.findIndex((p) => p.id === semesterId);
  const canPrevious = period !== "semester" || semesterIndex > 0;
  const canNext = period !== "semester" || semesterIndex < periods.length - 1;

  const rows = useMemo(() => {
    const q = query.trim().toLowerCase();
    return allClients
      .filter((c) => !q || c.name.toLowerCase().includes(q))
      .map((c) => {
        const sessions = c.sessions.filter((s) => matches(s, format, range));
        const latest =
          sessions
            .map((s) => s.date)
            .sort()
            .at(-1) ?? "";
        return { client: c, count: sessions.length, latest };
      })
      .filter((r) => r.count > 0)
      .sort((a, b) => b.latest.localeCompare(a.latest));
  }, [allClients, query, format, range]);

  const selected = allClients.find((c) => c.id === selectedId) ?? null;

  const detailSessions = useMemo(() => {
    if (!selected) return [];
    return selected.sessions
      .filter((s) => matches(s, format, range))
      .sort((a, b) =>
        timeSort === "terlama"
          ? sessionKey(a).localeCompare(sessionKey(b))
          : sessionKey(b).localeCompare(sessionKey(a)),
      );
  }, [selected, format, range, timeSort]);

  const lastDate =
    detailSessions
      .map((s) => s.date)
      .sort()
      .at(-1) ?? "";

  const noteSession =
    noteId !== null ? (allSessions.find((s) => String(s.id) === String(noteId)) ?? null) : null;
  const consentSession =
    consentSessionId !== null
      ? (detailSessions.find((s) => String(s.id) === String(consentSessionId)) ?? null)
      : null;

  const pwUsed = attemptState.count;

  function handleOpenClient(cid: string) {
    if (!hasAccess) return;
    setSelectedId(cid);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function closePw() {
    setPwInput("");
    navigate("/konselor");
  }

  async function handleUnlock(e: FormEvent) {
    e.preventDefault();
    if (verifying) return;
    setVerifying(true);
    try {
      const result = await unlockHistory(pwInput);
      if (result.status === "success") {
        setPwInput("");
        setPwError("");
        setToastMsg("Riwayat konseling dibuka. Terkunci otomatis dalam 30 menit.");
        return;
      }
      if (result.status === "locked") {
        setPwInput("");
        setPwError("Terlalu banyak percobaan. Coba lagi dalam 5 menit.");
        return;
      }
      if (result.status === "invalid") {
        setPwInput("");
        setPwError(`Kata sandi salah. Sisa percobaan: ${result.remainingAttempts}`);
        return;
      }
      setPwError("Penyimpanan browser tidak tersedia. Periksa pengaturan browser lalu coba lagi.");
    } finally {
      setVerifying(false);
    }
  }

  function backToClients() {
    setSelectedId(null);
    setNoteId(null);
    setConsentSessionId(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  function handleOpenConsent(id: string | number) {
    if (!hasAccess || !selectedId) {
      setConsentSessionId(null);
      return;
    }
    setConsentSessionId(id);
  }

  function handleOpenNote(id: string | number) {
    if (!selectedId || !hasAccess) {
      setToastMsg("Akses habis. Masukkan kata sandi kembali.");
      backToClients();
      return;
    }
    setNoteId(id);
  }

  return (
    <PageContainer role="counselor" spacing="none">
      {/* Timer Bar when Access Granted */}
      {hasAccess && (
        <div className="mb-6 flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 px-4 py-3 text-xs font-semibold text-[#064E3B] sm:px-5">
          <div className="flex items-center gap-2">
            <span className="h-2 w-2 animate-pulse rounded-full bg-[#064E3B]" />
            <span>
              Akses riwayat terbuka sementara (sisa waktu:{" "}
              <span className="font-mono font-bold">{timerText}</span>)
            </span>
          </div>
          <button
            type="button"
            onClick={lockHistory}
            className="inline-flex items-center gap-1.5 rounded-lg border border-emerald-300 bg-white px-3 py-1.5 text-xs font-bold text-[#064E3B] transition hover:bg-emerald-100/50"
          >
            <Lock className="h-3.5 w-3.5" />
            Kunci Sekarang
          </button>
        </div>
      )}

      {hasAccess &&
        (!selected ? (
          <>
            {/* ================= DAFTAR KLIEN ================= */}
            <PageHeader
              title="Riwayat Konseling"
              description="Pilih klien untuk membuka riwayat dan catatan konseling."
            />

            {/* Filter nama, format, dan periode waktu */}
            <div className="mt-6 space-y-3 rounded-2xl border border-gray-200 bg-white p-3 shadow-sm sm:p-4">
              <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
                <div className="relative min-w-0 flex-1">
                  <Search className="pointer-events-none absolute left-4 top-1/2 h-5 w-5 -translate-y-1/2 text-gray-400" />
                  <input
                    type="search"
                    value={query}
                    onChange={(e) => setQuery(e.target.value)}
                    placeholder="Cari nama klien ..."
                    className="w-full rounded-xl border border-gray-200 bg-gray-100/70 py-3 pl-12 pr-4 text-sm text-gray-800 outline-none placeholder:text-gray-500 focus:border-primary focus:bg-white focus:ring-4 focus:ring-primary/15"
                  />
                </div>

                <div
                  role="tablist"
                  aria-label="Format konseling"
                  className="flex w-full rounded-xl border border-gray-200 bg-gray-100/70 p-1 lg:w-auto"
                >
                  {(["Individu", "Kelompok"] as Format[]).map((f) => {
                    const active = format === f;
                    return (
                      <button
                        key={f}
                        type="button"
                        role="tab"
                        aria-selected={active}
                        onClick={() => setFormat(f)}
                        className={`flex-1 whitespace-nowrap rounded-lg px-4 py-2 text-sm transition lg:flex-none ${
                          active
                            ? "bg-white font-semibold text-gray-900 shadow-sm"
                            : "font-medium text-gray-500"
                        }`}
                      >
                        {f}
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="flex flex-col gap-3 border-t border-gray-100 pt-3 sm:flex-row sm:items-center sm:justify-between">
                <div className="flex flex-wrap items-center gap-1 rounded-xl border border-gray-200 bg-gray-100/70 p-1">
                  {PERIOD_OPTIONS.map(([key, labelText]) => (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setPeriod(key)}
                      className={`rounded-lg px-3 py-2 text-xs font-semibold transition sm:text-sm ${
                        period === key
                          ? "bg-white text-gray-900 shadow-sm"
                          : "text-gray-500 hover:text-gray-900"
                      }`}
                    >
                      {labelText}
                    </button>
                  ))}
                </div>

                <div className="flex flex-wrap items-center gap-2">
                  <button
                    type="button"
                    onClick={() => stepPeriod(-1)}
                    disabled={!canPrevious}
                    aria-label="Periode sebelumnya"
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-40"
                  >
                    <ChevronLeft className="h-4 w-4" />
                  </button>
                  <span className="min-w-[170px] flex-1 text-center text-sm font-semibold text-gray-800 sm:flex-none">
                    {label}
                  </span>
                  <button
                    type="button"
                    onClick={() => stepPeriod(1)}
                    disabled={!canNext}
                    aria-label="Periode berikutnya"
                    className="flex h-9 w-9 items-center justify-center rounded-lg border border-gray-200 bg-white text-gray-500 hover:bg-gray-50 disabled:opacity-40"
                  >
                    <ChevronRight className="h-4 w-4" />
                  </button>

                  {period === "semester" && (
                    <select
                      value={semesterId ?? ""}
                      onChange={(e) => setSemesterId(e.target.value)}
                      aria-label="Pilih semester akademik"
                      className="rounded-xl border border-gray-200 bg-white px-3 py-2.5 text-xs font-semibold text-gray-700 outline-none focus:border-primary focus:ring-2 focus:ring-primary/20"
                    >
                      {periods.map((p) => (
                        <option key={p.id} value={p.id}>
                          TA {p.ta} · {p.sem}
                        </option>
                      ))}
                    </select>
                  )}
                </div>
              </div>
            </div>

            <p className="mt-4 text-xs text-gray-500">
              Menampilkan {rows.length} klien · {format} · {label}
            </p>

            <ul className="mt-3 grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
              {rows.map(({ client, count, latest }) => (
                <li key={client.id}>
                  <button
                    type="button"
                    onClick={() => handleOpenClient(client.id)}
                    className="flex w-full flex-col rounded-2xl border border-gray-200 bg-white p-5 text-left transition hover:-translate-y-0.5 hover:border-[#36c08f]/60 hover:shadow-md"
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-full bg-primary-soft font-bold text-primary">
                        {initials(client.name)}
                      </div>
                      <div className="min-w-0 flex-1">
                        <p className="truncate font-semibold text-gray-900">
                          {client.name}
                        </p>
                        <p className="truncate text-xs text-gray-500">
                          {client.role}
                        </p>
                      </div>
                    </div>
                    <div className="mt-4 flex items-center justify-between border-t border-gray-100 pt-4 text-sm">
                      <span className="text-gray-600">
                        {count} sesi {format.toLowerCase()}
                      </span>
                      <span className="rounded-full bg-primary-soft px-2.5 py-1 text-xs font-semibold text-primary">
                        Selesai
                      </span>
                    </div>
                    <p className="mt-3 text-xs text-gray-400">
                      Terakhir: {fmtDate(latest)}
                    </p>
                  </button>
                </li>
              ))}
            </ul>

            {rows.length === 0 && (
              <div className="mt-5 rounded-2xl border border-dashed border-gray-300 bg-white p-10 text-center text-sm text-gray-500">
                Tidak ada klien yang cocok dengan filter ini.
              </div>
            )}
          </>
        ) : (
          <>
            {/* ================= DETAIL KLIEN ================= */}
            <nav className="flex items-center gap-2 text-sm text-gray-500">
              <button
                type="button"
                onClick={backToClients}
                className="inline-flex items-center gap-1.5 font-semibold text-primary hover:underline"
              >
                <ChevronLeft className="h-4 w-4" />
                Riwayat Konseling
              </button>
              <span>/</span>
              <span className="truncate text-gray-700">{selected.name}</span>
            </nav>

            <div className="mt-5 flex flex-col gap-5 rounded-2xl border border-gray-200 bg-white p-5 sm:flex-row sm:items-center sm:p-6">
              <div className="flex h-16 w-16 shrink-0 items-center justify-center rounded-full bg-gradient-to-br from-primary to-[#36c08f] text-xl font-bold text-white">
                {initials(selected.name)}
              </div>
              <div className="min-w-0 flex-1">
                <h2 className="text-xl font-bold sm:text-2xl">
                  {selected.name}
                </h2>
                <p className="mt-1 text-sm text-gray-500">
                  {selected.role} · {selected.email}
                </p>
              </div>
              <dl className="grid grid-cols-2 gap-3 sm:gap-6">
                <div className="rounded-xl bg-gray-50 px-3 py-2.5 text-center sm:px-4">
                  <dt className="text-xs text-gray-500">Total sesi</dt>
                  <dd className="mt-0.5 text-lg font-bold">
                    {detailSessions.length}
                  </dd>
                </div>
                <div className="rounded-xl bg-gray-50 px-3 py-2.5 text-center sm:px-4">
                  <dt className="text-xs text-gray-500">Terakhir</dt>
                  <dd className="mt-0.5 text-sm font-semibold">
                    {lastDate ? fmtDate(lastDate) : "-"}
                  </dd>
                </div>
              </dl>
            </div>

            <div className="mt-8 flex flex-wrap items-center justify-between gap-3">
              <div>
                <h3 className="text-base font-bold text-gray-900">
                  Riwayat sesi
                </h3>
                <p className="text-xs text-gray-500">
                  {format} · {label}
                </p>
              </div>
              <div className="relative">
                <select
                  value={timeSort}
                  onChange={(e) =>
                    setTimeSort(e.target.value as "terbaru" | "terlama")
                  }
                  className="w-full appearance-none rounded-xl border border-gray-200 bg-gray-100/70 py-2.5 pl-4 pr-10 text-sm text-gray-600 outline-none focus:border-primary focus:bg-white sm:w-auto"
                >
                  <option value="terbaru">Waktu terbaru</option>
                  <option value="terlama">Waktu terlama</option>
                </select>
                <ChevronDown className="pointer-events-none absolute right-3.5 top-1/2 h-4 w-4 -translate-y-1/2 text-gray-500" />
              </div>
            </div>

            {detailSessions.length === 0 ? (
              <p className="mt-4 text-sm text-gray-500">
                Tidak ada sesi yang cocok dengan filter ini.
              </p>
            ) : (
              <ol className="relative mt-4 space-y-4 border-l-2 border-gray-200 pl-5 sm:pl-7">
                {detailSessions.map((s) => (
                  <li key={s.id} className="relative">
                    <span className="absolute -left-[27px] top-5 h-3 w-3 rounded-full border-2 border-white bg-[#36c08f] sm:-left-[35px]" />
                    <div className="rounded-2xl border border-gray-200 bg-white p-5">
                      <div className="flex flex-wrap items-start justify-between gap-3">
                        <div>
                          <p className="font-semibold text-gray-900">
                            {s.topic}
                          </p>
                          <p className="mt-0.5 text-sm text-gray-500">
                            {fmtDate(s.date)} · {s.time} WITA
                          </p>
                        </div>
                        <span
                          className={`rounded-full px-2.5 py-1 text-xs font-semibold ${
                            s.format === "Kelompok"
                              ? "bg-yellow-100 text-yellow-800"
                              : "bg-emerald-100 text-emerald-800"
                          }`}
                        >
                          {s.format}
                        </span>
                      </div>
                      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-gray-100 pt-4">
                        <span className="rounded-full bg-primary-soft px-2.5 py-1 text-xs font-semibold text-primary">
                          Selesai
                        </span>
                        <div className="flex flex-wrap items-center gap-2">
                          <button
                            type="button"
                            onClick={() => handleOpenConsent(s.id)}
                            className="inline-flex items-center gap-1.5 rounded-lg border border-primary px-3.5 py-2 text-sm font-semibold text-primary hover:bg-primary-soft"
                          >
                            <FileSignature className="h-4 w-4" />
                            Lihat informed consent
                          </button>
                          <button
                            type="button"
                            onClick={() => handleOpenNote(s.id)}
                            className="inline-flex items-center gap-1.5 rounded-lg bg-primary px-3.5 py-2 text-sm font-semibold text-white hover:bg-primary-dark"
                          >
                            <Eye className="h-4 w-4" />
                            Lihat catatan
                          </button>
                        </div>
                      </div>
                    </div>
                  </li>
                ))}
              </ol>
            )}
          </>
        ))}

      {/* ================= MODAL PASSWORD ================= */}
      {!hasAccess && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0c2619]/45 p-4 backdrop-blur-[2px]">
          <form
            onSubmit={handleUnlock}
            className="w-full max-w-md rounded-2xl bg-white p-6 shadow-2xl"
          >
            <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-primary-soft text-primary">
              <Lock className="h-6 w-6" />
            </div>
            <h2 className="text-lg font-bold">Buka Riwayat Konseling</h2>
            <p className="mt-1 text-sm text-gray-500">
              Masukkan kata sandi khusus untuk membuka{" "}
              <span className="font-semibold text-gray-700">
                seluruh riwayat dan catatan konseling
              </span>
              . Ini berbeda dari kata sandi login Anda.
            </p>

            <label
              htmlFor="pwInput"
              className="mt-5 block text-sm font-medium text-gray-700"
            >
              Kata sandi
            </label>
            <div className="relative mt-1.5">
              <input
                id="pwInput"
                type={pwVisible ? "text" : "password"}
                autoComplete="off"
                autoFocus
                value={pwInput}
                onChange={(e) => setPwInput(e.target.value)}
                disabled={pwLocked || verifying}
                placeholder="Masukkan 4 digit sandi riwayat"
                className="w-full rounded-xl border border-gray-300 py-2.5 pl-4 pr-20 text-sm outline-none focus:border-primary focus:ring-4 focus:ring-primary/15 disabled:bg-gray-100"
              />
              <button
                type="button"
                onClick={() => setPwVisible((v) => !v)}
                className="absolute right-2 top-1/2 flex -translate-y-1/2 items-center gap-1 rounded-md px-2 py-1 text-xs font-semibold text-primary hover:bg-primary-soft"
              >
                {pwVisible ? (
                  <EyeOff className="h-3.5 w-3.5" />
                ) : (
                  <Eye className="h-3.5 w-3.5" />
                )}
                {pwVisible ? "Sembunyikan" : "Lihat"}
              </button>
            </div>

            {pwError && (
              <div className="mt-2 flex items-center gap-1.5 text-sm text-red-600">
                <ShieldAlert className="h-4 w-4 shrink-0" />
                <span>{pwError}</span>
              </div>
            )}
            {!pwError && pwUsed > 0 && !pwLocked && (
              <p className="mt-1 text-xs text-gray-500">
                Sisa percobaan: {MAX_ATTEMPTS - pwUsed}
              </p>
            )}

            <div className="mt-6 flex justify-end gap-2">
              <button
                type="button"
                onClick={closePw}
                className="rounded-xl border border-gray-300 px-4 py-2.5 text-sm font-semibold text-gray-700 hover:bg-gray-50"
              >
                Batal
              </button>
              <button
                type="submit"
                disabled={pwLocked || verifying || pwInput.length === 0}
                className="rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-dark disabled:opacity-50"
              >
                {verifying ? "Memverifikasi..." : "Buka"}
              </button>
            </div>
          </form>
        </div>
      )}

      {/* ================= MODAL LIHAT INFORMED CONSENT ================= */}
      {hasAccess && selected && consentSession && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0c2619]/45 p-4 backdrop-blur-[2px]">
          <section
            role="dialog"
            aria-modal="true"
            aria-labelledby="consent-view-title"
            className="flex max-h-[92vh] w-full max-w-3xl flex-col overflow-hidden rounded-2xl bg-white shadow-2xl"
          >
            <div className="flex items-start justify-between gap-4 border-b border-gray-200 p-5">
              <div>
                <h2
                  id="consent-view-title"
                  className="text-lg font-bold text-gray-900"
                >
                  Informed Consent
                </h2>
                <p className="mt-1 text-sm text-gray-500">
                  {selected.name} · {fmtDate(consentSession.date)}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setConsentSessionId(null)}
                aria-label="Tutup informed consent"
                className="rounded-lg p-2 hover:bg-gray-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="min-h-0 flex-1 overflow-y-auto">
              <object
                data={`${CONSENT_PDF_URL}#toolbar=0&navpanes=0`}
                type="application/pdf"
                className="h-[55vh] w-full"
                aria-label="Dokumen informed consent"
              >
                <div className="p-6 text-center text-sm text-gray-600">
                  Browser tidak dapat menampilkan PDF.{" "}
                  <a
                    href={CONSENT_PDF_URL}
                    target="_blank"
                    rel="noreferrer"
                    className="font-semibold text-primary underline"
                  >
                    Buka dokumen di tab baru
                  </a>
                </div>
              </object>
              <p className="border-t border-gray-200 p-5 text-sm text-gray-600">
                Ini adalah dokumen informed consent resmi SiCARE. Riwayat persetujuan
                dan status persetujuan disimpan dalam rekam medis terproteksi.
              </p>
            </div>
            <div className="flex justify-end border-t border-gray-200 p-5">
              <a
                href={CONSENT_PDF_URL}
                download="informed-consent.pdf"
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-white hover:bg-primary-dark"
              >
                <Download className="h-4 w-4" />
                Unduh PDF
              </a>
            </div>
          </section>
        </div>
      )}

      {/* ================= MODAL BACA CATATAN ================= */}
      {hasAccess && noteSession && selected && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-[#0c2619]/45 p-4 backdrop-blur-[2px]">
          <div className="flex max-h-[88vh] w-full max-w-xl flex-col rounded-2xl bg-white shadow-2xl">
            <div className="flex items-start justify-between gap-4 border-b border-gray-200 p-5 sm:p-6">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wide text-primary">
                  Catatan terbuka sementara
                </p>
                <h2 className="mt-1 text-lg font-bold">{noteSession.topic}</h2>
                <p className="mt-1 text-sm text-gray-500">
                  {fmtDate(noteSession.date)} · {noteSession.time} WITA ·{" "}
                  {noteSession.format}
                </p>
              </div>
              <button
                type="button"
                onClick={() => setNoteId(null)}
                aria-label="Tutup"
                className="rounded-lg p-2 hover:bg-gray-100"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="overflow-y-auto p-5 sm:p-6">
              <h3 className="text-sm font-semibold text-gray-700">
                Ringkasan sesi
              </h3>
              <p className="mt-1.5 whitespace-pre-line text-sm leading-relaxed text-gray-700">
                {noteSession.summary}
              </p>
              <h3 className="mt-5 text-sm font-semibold text-gray-700">
                Catatan konselor
              </h3>
              <p className="mt-1.5 whitespace-pre-line text-sm leading-relaxed text-gray-700">
                {noteSession.note}
              </p>
              <p className="mt-5 text-xs text-gray-400">
                Akses terkunci otomatis dalam {timerText}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* ================= TOAST ================= */}
      <div
        className={`pointer-events-none fixed bottom-6 left-1/2 z-50 -translate-x-1/2 rounded-xl bg-gray-900 px-4 py-3 text-sm text-white shadow-lg transition duration-300 ${
          toastMsg ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
        }`}
      >
        {toastMsg}
      </div>
    </PageContainer>
  );
}
